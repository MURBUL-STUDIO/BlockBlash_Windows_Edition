import pygame
import random
import os
import sys

pygame.init()

WIDTH, HEIGHT = 600, 700
GRID_SIZE = 7
CELL_SIZE = 60
MARGIN = 4
GRID_TOP = 100
GRID_LEFT = (WIDTH - GRID_SIZE * (CELL_SIZE + MARGIN)) // 2
PIECE_AREA_Y = HEIGHT - 150

WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Block Blast Windows Edition")



WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BG = (30, 30, 60)
BTN_COLOR = (50, 150, 200)
BTN_HOVER = (70, 170, 220)
COLORS = [(255, 100, 100), (100, 255, 100), (100, 100, 255), (255, 255, 100), (255, 100, 255), (100, 255, 255)]
FONT = pygame.font.SysFont("Arial", 28)
LARGE_FONT = pygame.font.SysFont("Arial", 48)
SCORE_FONT = pygame.font.SysFont("Arial", 36)

desktop = os.path.join(os.path.expanduser("~"), "Desktop")
save_dir = os.path.join(desktop, "Block Blast Windows Edition", "userdt")
os.makedirs(save_dir, exist_ok=True)
record_file = os.path.join(save_dir, "record.txt")

sound_path = os.path.join(desktop, "Block Blast Windows Edition", "sounds", "HF.wav")
clear_sound = pygame.mixer.Sound(sound_path) if os.path.exists(sound_path) else None

if os.path.exists(record_file):
    with open(record_file, "r") as f:
        try:
            record = int(f.read())
        except:
            record = 0
else:
    record = 0

desktop = os.path.join(os.path.expanduser("~"), "Desktop")
icon_path = os.path.join(desktop, "Block Blast Windows Edition", "icon.ico")

if os.path.exists(icon_path):
    try:
        icon = pygame.image.load(icon_path)
        pygame.display.set_icon(icon)
    except pygame.error as e:
        print(f"Ошибка загрузки иконки: {e}")
else:
    print(f"Иконка не найдена по пути: {icon_path}")

score = 0
grid = [[0] * GRID_SIZE for _ in range(GRID_SIZE)]
game_over = False
mode = None
time_limit = 31
added_time = 0
start_ticks = 0
paused = False
paused_time = 0
total_paused_duration = 0

PIECE_SLOTS = [WIDTH // 8, 3 * WIDTH // 8, 5 * WIDTH // 8, 7 * WIDTH // 8]

menu_blocks = []
for y in range(0, HEIGHT, CELL_SIZE + MARGIN):
    row = []
    for x in range(0, WIDTH, CELL_SIZE + MARGIN):
        color = random.choice(COLORS)
        target = random.choice(COLORS)
        row.append({"color": list(color), "target": list(target)})
    menu_blocks.append(row)

def update_menu_blocks():
    for row in menu_blocks:
        for block in row:
            for i in range(3):
                if block["color"][i] < block["target"][i]:
                    block["color"][i] += 1
                elif block["color"][i] > block["target"][i]:
                    block["color"][i] -= 1
            if block["color"] == block["target"]:
                block["target"] = list(random.choice(COLORS))

def draw_main_menu_background():
    update_menu_blocks()
    for y_idx, row in enumerate(menu_blocks):
        for x_idx, block in enumerate(row):
            x = x_idx * (CELL_SIZE + MARGIN)
            y = y_idx * (CELL_SIZE + MARGIN)
            r = pygame.Rect(x, y, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(WIN, block["color"], r)

def draw_main_menu():
    draw_main_menu_background()
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 150))
    WIN.blit(overlay, (0, 0))
    title = LARGE_FONT.render("Block Blast Windows Edition", True, WHITE)
    WIN.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 3))
    mx, my = pygame.mouse.get_pos()
    btn1 = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2, 200, 50)
    btn2 = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 70, 200, 50)
    btn3 = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 140, 200, 50)
    for btn, text in [(btn1, "Classic"), (btn2, "Time Mode"), (btn3, "Exit")]:
        color = BTN_HOVER if btn.collidepoint((mx, my)) else BTN_COLOR
        pygame.draw.rect(WIN, color, btn)
        pygame.draw.rect(WIN, BLACK, btn, 3)
        t = FONT.render(text, True, WHITE)
        WIN.blit(t, (btn.centerx - t.get_width() // 2, btn.centery - t.get_height() // 2))
    return btn1, btn2, btn3

def draw_game_over_screen():
    draw_main_menu_background()
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    WIN.blit(overlay, (0, 0))
    title = LARGE_FONT.render("Game Over", True, WHITE)
    WIN.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 3))
    s = FONT.render(f"Score: {score}", True, WHITE)
    r = FONT.render(f"Record: {record}", True, WHITE)
    WIN.blit(s, (WIDTH // 2 - s.get_width() // 2, HEIGHT // 3 + 60))
    WIN.blit(r, (WIDTH // 2 - r.get_width() // 2, HEIGHT // 3 + 100))
    mx, my = pygame.mouse.get_pos()
    btn_restart = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 40, 200, 50)
    btn_menu = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 110, 200, 50)
    for btn, label in [(btn_restart, "Restart"), (btn_menu, "Main Menu")]:
        color = BTN_HOVER if btn.collidepoint((mx, my)) else BTN_COLOR
        pygame.draw.rect(WIN, color, btn)
        pygame.draw.rect(WIN, BLACK, btn, 3)
        t = FONT.render(label, True, WHITE)
        WIN.blit(t, (btn.centerx - t.get_width() // 2, btn.centery - t.get_height() // 2))
    return btn_restart, btn_menu

def draw_pause_menu():
    draw_main_menu_background()
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    WIN.blit(overlay, (0, 0))
    title = LARGE_FONT.render("Paused", True, WHITE)
    WIN.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 3))
    mx, my = pygame.mouse.get_pos()
    btn_resume = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 - 30, 200, 50)
    btn_restart = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 40, 200, 50)
    btn_menu = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 110, 200, 50)
    for btn, label in [(btn_resume, "Continue"), (btn_restart, "Restart"), (btn_menu, "Main Menu")]:
        color = BTN_HOVER if btn.collidepoint((mx, my)) else BTN_COLOR
        pygame.draw.rect(WIN, color, btn)
        pygame.draw.rect(WIN, BLACK, btn, 2)
        t = FONT.render(label, True, WHITE)
        WIN.blit(t, (btn.centerx - t.get_width() // 2, btn.centery - t.get_height() // 2))
    return btn_resume, btn_restart, btn_menu

class Piece:
    def __init__(self, shape, x):
        self.shape = shape
        self.color = random.choice(COLORS)
        w = len(shape[0]) * (CELL_SIZE + MARGIN) - MARGIN
        self.x = x - w // 2
        self.y = PIECE_AREA_Y
        self.dragging = False

    def draw(self):
        for i, row in enumerate(self.shape):
            for j, cell in enumerate(row):
                if cell:
                    rect = pygame.Rect(self.x + j * (CELL_SIZE + MARGIN), self.y + i * (CELL_SIZE + MARGIN), CELL_SIZE, CELL_SIZE)
                    pygame.draw.rect(WIN, self.color, rect)
                    pygame.draw.rect(WIN, BLACK, rect, 2)

    def point_inside(self, pos):
        px, py = pos
        for i, row in enumerate(self.shape):
            for j, cell in enumerate(row):
                if cell:
                    r = pygame.Rect(self.x + j * (CELL_SIZE + MARGIN), self.y + i * (CELL_SIZE + MARGIN), CELL_SIZE, CELL_SIZE)
                    if r.collidepoint(px, py):
                        return True
        return False

    def try_place(self):
        gx = (self.x - GRID_LEFT + CELL_SIZE // 2) // (CELL_SIZE + MARGIN)
        gy = (self.y - GRID_TOP + CELL_SIZE // 2) // (CELL_SIZE + MARGIN)
        coords = []
        for i, row in enumerate(self.shape):
            for j, cell in enumerate(row):
                if cell:
                    x2, y2 = gx + j, gy + i
                    if x2 < 0 or x2 >= GRID_SIZE or y2 < 0 or y2 >= GRID_SIZE or grid[y2][x2]:
                        return False
                    coords.append((y2, x2))
        for y2, x2 in coords:
            grid[y2][x2] = self.color
        global score, record, added_time
        score += len(coords) * 10
        lines_cleared = clear_lines()
        if lines_cleared and mode == "time":
            added_time += lines_cleared * 10
        if score > record:
            record = score
            with open(record_file, "w") as f:
                f.write(str(record))
        return True

    def handle(self, event):
        max_x = WIDTH - (len(self.shape[0]) * (CELL_SIZE + MARGIN) - MARGIN)
        max_y = HEIGHT - (len(self.shape) * (CELL_SIZE + MARGIN) - MARGIN)
        if event.type == pygame.MOUSEBUTTONDOWN and self.point_inside(event.pos):
            self.dragging = True
            mx, my = event.pos
            self.ox, self.oy = self.x - mx, self.y - my
        elif event.type == pygame.MOUSEBUTTONUP and self.dragging:
            placed = self.try_place()
            self.dragging = False
            return placed
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            mx, my = event.pos
            self.x = max(0, min(mx + self.ox, max_x))
            self.y = max(GRID_TOP, min(my + self.oy, max_y))
        return False

def clear_lines():
    cleared = 0
    rows = [i for i in range(GRID_SIZE) if all(grid[i])]
    cols = [j for j in range(GRID_SIZE) if all(grid[i][j] for i in range(GRID_SIZE))]
    for i in rows:
        for j in range(GRID_SIZE):
            grid[i][j] = 0
        cleared += 1
    for j in cols:
        for i in range(GRID_SIZE):
            grid[i][j] = 0
        cleared += 1
    if cleared >= 4 and clear_sound:
        clear_sound.play()
    return cleared

def generate_pieces():
    shapes = [
    [[1, 1]],                   # 2×1 горизонталь
    [[1], [1]],                 # 1×2 вертикаль
    [[1, 1], [1, 1]],           # 2×2 квадрат
    [[1, 1, 1]],                # 3×1 горизонталь
    [[1], [1], [1]],            # 1×3 вертикаль
    [[1, 1, 1, 1]],             # 4×1 горизонталь
    [[1], [1], [1], [1]],       # 1×4 вертикаль
    [[1, 1, 1], [1, 1, 1], [1, 1, 1]],  # 3×3 квадрат
    [[1, 0], [1, 1]],           # L малая
    [[0, 1], [1, 1]],           # L малая обратная
    [[1, 1, 0], [0, 1, 1]],     # S (зигзаг вправо)
    [[0, 1, 1], [1, 1, 0]],     # Z (зигзаг влево)
    [[1, 1, 1], [0, 1, 0]],     # T-образная
    [[1, 0, 0], [1, 1, 1]],     # L большая
    [[0, 0, 1], [1, 1, 1]],
    [[1, 1, 1],[1, 0, 0],[1, 0, 0]],
    [[1, 1, 1],[0, 0, 1],[0, 0, 1]]
]

    selected_shapes = []
    while len(selected_shapes) < 3:
        shape = random.choice(shapes)
        if shape not in selected_shapes:
            selected_shapes.append(shape)
    return [Piece(shape, x) for shape, x in zip(selected_shapes, random.sample(PIECE_SLOTS, 3))]

def can_place_any(pieces):
    for piece in pieces:
        for y in range(GRID_SIZE):
            for x in range(GRID_SIZE):
                fits = True
                for i, row in enumerate(piece.shape):
                    for j, cell in enumerate(row):
                        if cell:
                            if y + i >= GRID_SIZE or x + j >= GRID_SIZE or grid[y + i][x + j]:
                                fits = False
                if fits:
                    return True
    return False

def restart_game(selected_mode):
    global grid, score, pieces, game_over, mode, time_limit, added_time, start_ticks, paused, paused_time, total_paused_duration
    grid = [[0] * GRID_SIZE for _ in range(GRID_SIZE)]
    score = 0
    pieces = generate_pieces()
    game_over = False
    mode = selected_mode
    paused = False
    paused_time = 0
    total_paused_duration = 0
    if mode == "time":
        time_limit = 31
        added_time = 0
        start_ticks = pygame.time.get_ticks()
        elapsed = 0

pieces = []
clock = pygame.time.Clock()

while True:
    clock.tick(60)
    WIN.fill(BG)
    if mode is None:
        btn1, btn2, btn3 = draw_main_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if btn1.collidepoint(event.pos):
                    restart_game("classic")
                if btn2.collidepoint(event.pos):
                    restart_game("time")
                if btn3.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
    else:
        pause_btn = pygame.Rect(WIDTH - 130, 10, 120, 40)
        color = BTN_HOVER if pause_btn.collidepoint(pygame.mouse.get_pos()) else BTN_COLOR
        pygame.draw.rect(WIN, color, pause_btn)
        pygame.draw.rect(WIN, BLACK, pause_btn, 2)
        txt = FONT.render("Pause", True, WHITE)
        WIN.blit(txt, (pause_btn.centerx - txt.get_width() // 2, pause_btn.centery - txt.get_height() // 2))

        s = SCORE_FONT.render(f"Score: {score}", True, WHITE)
        r = SCORE_FONT.render(f"Record: {record}", True, WHITE)
        WIN.blit(s, (20, 20))
        WIN.blit(r, (20, 60))

        if mode == "time":
            if not paused:
                elapsed = (pygame.time.get_ticks() - start_ticks - total_paused_duration) / 1000
                t_left = time_limit + added_time - elapsed
                current_time_left = max(0, int(t_left))
                t = SCORE_FONT.render(f"Time: {current_time_left}", True, WHITE)
                WIN.blit(t, (WIDTH - 200, 60))
            if current_time_left <= 0:
                game_over = True



        if paused:
            btn_resume, btn_restart, btn_menu = draw_pause_menu()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if btn_resume.collidepoint(event.pos):
                        total_paused_duration += pygame.time.get_ticks() - paused_time
                        paused = False
                    if btn_restart.collidepoint(event.pos):
                        restart_game(mode)
                    if btn_menu.collidepoint(event.pos):
                        mode = None
        else:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if pause_btn.collidepoint(event.pos):
                        paused = True
                        paused_time = pygame.time.get_ticks()
                    if game_over:
                        btn_restart, btn_menu = draw_game_over_screen()
                        if btn_restart.collidepoint(event.pos):
                            restart_game(mode)
                        if btn_menu.collidepoint(event.pos):
                            mode = None
                if not game_over:
                    for p in pieces[:]:
                        if p.handle(event):
                            pieces.remove(p)
            for i in range(GRID_SIZE):
                for j in range(GRID_SIZE):
                    r = pygame.Rect(GRID_LEFT + j * (CELL_SIZE + MARGIN), GRID_TOP + i * (CELL_SIZE + MARGIN), CELL_SIZE, CELL_SIZE)
                    pygame.draw.rect(WIN, grid[i][j] or WHITE, r)
                    pygame.draw.rect(WIN, BLACK, r, 2)
            for p in pieces:
                p.draw()
            if not game_over and pieces and not can_place_any(pieces):
                game_over = True
            if not game_over and not pieces:
                pieces = generate_pieces()
            if game_over:
                btn_restart, btn_menu = draw_game_over_screen()
    pygame.display.update()
